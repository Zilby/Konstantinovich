No real problems with this knight's tour. 
Runs quickly on any board lower than 8. 
Sincerely,
Zilb
